require 'test_helper'

class Api::V1::GuidesControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end

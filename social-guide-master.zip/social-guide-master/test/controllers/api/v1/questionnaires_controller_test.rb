require 'test_helper'

class Api::V1::QuestionnairesControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
